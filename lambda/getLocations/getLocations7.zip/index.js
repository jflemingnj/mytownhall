'use strict';
console.log('Loading event');

function getLocations(){
	var locations = [];
	
	var mysql = require('mysql');
	var json = require('json');
	
	var connection = mysql.createConnection({
	  host     : 'mytownhalldb.cckbbirmfdru.us-east-1.rds.amazonaws.com',
	  user     : 'mytownhall',
	  password : 'mytownhallpass',
	  database : 'mytownhalldb',
	  port     : 3306
	});	
	
	connection.connect(function(err) {
	  if (err) {
	    console.error('Database connection failed: ' + err.stack);
	    return;
	  }
	
	  console.log('Connected to database.');
	});
	
	var queryString = 'SELECT * FROM location';
	 
	connection.query(queryString, function(err, rows, fields) {
	    if (err) throw err;
	 
	    for (var i in rows) {
	        console.log('row:' + JSON.stringify(rows[i]));
	        locations.push(rows[i]);
	    }
	    
	    console.log('rows:' + JSON.stringify(rows));
	});	
	
	connection.end();	

	return locations;
}

            
exports.handler = function(event, context, callback) {
    
    setTimeout(function(){
	    var response = '""';
	    var locations = getLocations();
	
	    if (locations != undefined){
	        response = JSON.stringify(locations);
	    }
	    
	  var name = (event.name === undefined ? 'No-Name' : event.name);
	  console.log('"Hello":"' + name + '"');
	  callback(null, {"locations":locations}); // SUCCESS with message
	  }, 500);
	  
};